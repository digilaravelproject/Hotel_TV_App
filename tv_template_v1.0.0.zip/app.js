(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const $$ = (sel) => document.querySelectorAll(sel);

  function updateClock() {
    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const h12 = hours % 12 || 12;
    $('time-display').textContent = `${h12}:${minutes} ${ampm}`;

    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    $('date-display').textContent = `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]}`;
  }

  function renderData(json) {
    const device = json.device || {};
    const hotel = json.hotel || {};

    $('room-no').textContent = device.room_no || '--';
    $('device-info').textContent = `Device: ${device.device_id || '--'}`;
    $('guest-name').textContent = hotel.owner_name || '--';
    $('greeting').textContent = `Welcome to ${hotel.hotel_name || 'Hotel'}!`;

    // Hotel logo
    if (hotel.media && hotel.media.logo_image) {
      const logo = document.querySelector('.logo-img');
      if (logo) logo.src = hotel.media.logo_image;
    }

    // Cover image
    if (hotel.media && hotel.media.cover_image) {
      document.body.style.backgroundImage = `url(${hotel.media.cover_image})`;
    }

    // Slider images
    if (hotel.media && hotel.media.slider_images && hotel.media.slider_images.length > 0) {
      console.log('Slider images:', hotel.media.slider_images);
    }
  }

  function handleError(err) {
    console.error('Data load error:', err);
    $('greeting').textContent = 'Unable to load data. Please try again.';
  }

  function loadData() {
    fetch('./data.json')
      .then((res) => {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
      })
      .then((json) => renderData(json))
      .catch(handleError);
  }

  document.addEventListener('click', function (e) {
    const item = e.target.closest('.service-item');
    if (item) {
      const service = item.dataset.service;
      console.log('Service selected:', service);
    }
  });

  updateClock();
  setInterval(updateClock, 1000);
  loadData();
})();
