/* ================= 1. CAROUSEL & FOCUS LOGIC ================= */
const track = document.getElementById("menuTrack");
const centerIndex = 3;

function updateCarouselPosition() {
    var vWidth = 1920;
    var totalSlot = vWidth * 0.142857;
    var offset = (vWidth / 2) - (centerIndex * totalSlot) - (totalSlot / 2);
    if (track) track.style.transform = 'translate3d(' + offset + 'px, 0px, 0px)';
}

function syncFocus() {
    if (!track) return;
    var allIcons = Array.prototype.slice.call(track.querySelectorAll(".icon-item")).filter(function (el) {
        return el.style.display !== 'none' && window.getComputedStyle(el).display !== 'none';
    });

    for (var i = 0; i < allIcons.length; i++) {
        var icon = allIcons[i];
        icon.classList.remove("active-focus");
        var img = icon.querySelector(".icon-img");
        if (img) img.classList.remove("bounce");
    }

    var target = allIcons[centerIndex] || allIcons[0];
    if (target) {
        target.focus();
        target.classList.add("active-focus");

        // Save the focused label & action to sessionStorage to restore it only on Back navigation
        var labelEl = target.querySelector(".icon-label");
        var label = labelEl ? labelEl.innerText.trim() : null;
        var action = target.getAttribute('data-action') || target.getAttribute('data-link') || target.getAttribute('href');

        if (label) {
            sessionStorage.setItem("lastFocusedLabel", label);
        }
        if (action) {
            sessionStorage.setItem("lastFocusedAction", action);
        }

        var targetImg = target.querySelector(".icon-img");
        if (targetImg) {
            void targetImg.offsetWidth;
            targetImg.classList.add("bounce");
        }
    }
}

function rotateToItem(targetItem) {
    if (!track || !targetItem) return;
    var visibleItems = Array.prototype.slice.call(track.querySelectorAll('.icon-item')).filter(function (el) {
        return el.style.display !== 'none' && window.getComputedStyle(el).display !== 'none';
    });

    var targetIndex = visibleItems.indexOf(targetItem);
    if (targetIndex === -1 || targetIndex === centerIndex) return;

    var diff = targetIndex - centerIndex;
    if (diff > 0) {
        for (var i = 0; i < diff; i++) {
            var firstVisible = track.querySelector('.icon-item:not([style*="display: none"])');
            if (firstVisible) track.appendChild(firstVisible);
        }
    } else if (diff < 0) {
        for (var k = 0; k < Math.abs(diff); k++) {
            var vItems = Array.prototype.slice.call(track.querySelectorAll('.icon-item')).filter(function (el) {
                return el.style.display !== 'none' && window.getComputedStyle(el).display !== 'none';
            });
            var lastVis = vItems[vItems.length - 1];
            if (lastVis) track.insertBefore(lastVis, track.firstElementChild);
        }
    }
    syncFocus();
}

function rotate(dir) {
    if (!track) return;
    const isRTL = document.body.classList.contains('rtl-mode');
    let moveDir = dir;
    if (isRTL) {
        moveDir = (dir === 'right') ? 'left' : 'right';
    }

    if (moveDir === 'right') {
        var firstVisible = track.querySelector('.icon-item:not([style*="display: none"])');
        if (firstVisible) track.appendChild(firstVisible);
    } else {
        var visibleItems = Array.prototype.slice.call(track.querySelectorAll('.icon-item')).filter(function (el) {
            return el.style.display !== 'none' && window.getComputedStyle(el).display !== 'none';
        });
        var lastVisible = visibleItems[visibleItems.length - 1];
        if (lastVisible) track.insertBefore(lastVisible, track.firstElementChild);
    }
    syncFocus();
}

/* ================= 2. LIVE TV LOGIC (Refactored for Flutter Bridge) ================= */
async function handleLiveTV() {
    var savedPort = localStorage.getItem('selectedLiveTvPort') || localStorage.getItem('selectedHdmiPort') || '';

    if (window.flutterBridge && typeof window.flutterBridge.launchLiveTv === 'function') {
        try {
            var res = window.flutterBridge.launchLiveTv(savedPort);
            if (res && typeof res.then === 'function') {
                await res;
            }
            return; // Single-invocation guard: skip multiple fallback fetch calls or re-invocations
        } catch (err) {
            console.error('Direct launchLiveTv failed:', err);
            return; // Prevent fallback double-invocation on error
        }
    }

    const serial = localStorage.getItem('deviceSerial');
    const ip = localStorage.getItem('deviceIp');

    if (!serial || !ip) {
        try {
            if (window.flutterBridge && typeof window.flutterBridge.identifyDevice === 'function') {
                const device = await window.flutterBridge.identifyDevice(ip);
                if (device && device.success && device.serial) {
                    localStorage.setItem('deviceSerial', device.serial);
                    localStorage.setItem('deviceIp', device.ip);
                    return handleLiveTV();
                }
            }
            throw new Error('Failed to identify device');
        } catch (err) {
            console.error('Device identification failed:', err);
            return;
        }
    }

    try {
        const config = await fetch(`admin/devices/${serial}.json?t=${Date.now()}`).then(r => r.json());

        if (config.tv_source === "TV APP") {
            if (window.flutterBridge && typeof window.flutterBridge.launchApp === 'function') {
                await window.flutterBridge.launchApp(config.package);
            }
        } else if (config.tv_source === "HDMI") {
            if (window.flutterBridge && typeof window.flutterBridge.launchHdmi === 'function') {
                await window.flutterBridge.launchHdmi(config.package || savedPort);
            }
        } else if (config.tv_source === "IPTV") {
            if (window.flutterBridge && typeof window.flutterBridge.launchIptv === 'function') {
                await window.flutterBridge.launchIptv(config.package, config.iptv_config || "iptv/all.json");
            }
        }
    } catch (e) {
        console.error("Launch error", e);
    }
}

/* ================= 3. INITIALIZATION & DATA ================= */
let currentData = {
    "direction": "ltr",
    "room_label": "Room",
    "city_name": "Mumbai",
    "greetings": { "morning": "Good Morning", "afternoon": "Good Afternoon", "evening": "Good Evening", "night": "Good Night" },
    "days": { "sun": "Sun", "mon": "Mon", "tue": "Tue", "wed": "Wed", "thu": "Thu", "fri": "Fri", "sat": "Sat" },
    "months": { "jan": "Jan", "feb": "Feb", "mar": "Mar", "apr": "Apr", "may": "May", "jun": "Jun", "jul": "Jul", "aug": "Aug", "sep": "Sep", "oct": "Oct", "nov": "Nov", "dec": "Dec" },
    "icons": {}
};

async function fetchHotelConfig() {
    var injected = window.tvLoginData || (window.parent && window.parent.tvLoginData);
    if (injected) {
        var normalized = injected.data || injected;
        localStorage.setItem('cachedHotelData', JSON.stringify(normalized));
        return normalized;
    }

    // Try network first, always fetch fresh data.json
    const filename = window.HOTEL_DATA_FILE || 'data.json';
    const paths = [filename, `../${filename}`, 'data.json', '../data.json'];

    for (let path of paths) {
        try {
            const res = await fetch(`${path}?t=${Date.now()}`);
            if (res.ok) {
                var config = await res.json();
                var normalized = config.data || config;
                localStorage.setItem('cachedHotelData', JSON.stringify(normalized));
                return normalized;
            }
        } catch (e) {
            console.warn(`Failed to fetch config from ${path}:`, e);
        }
    }

    // Network failed — fall back to localStorage cache
    const cached = localStorage.getItem('cachedHotelData');
    if (cached) {
        try { return JSON.parse(cached); } catch (e) {
            console.error("Failed parsing cached config:", e);
        }
    }
    return null;
}

let slideImages = [];
let currentImageIndex = 0;
let activeSlideIndex = 0;
let sliderIntervalId = null;

function initSlider(images) {
    if (sliderIntervalId) clearInterval(sliderIntervalId);
    slideImages = images || [];

    // Fallback: If no slider images are specified, try default cover or main.jpg
    if (slideImages.length === 0) {
        const cached = localStorage.getItem('cachedHotelData');
        if (cached) {
            try {
                const config = JSON.parse(cached);
                if (config.hotel && config.hotel.media && config.hotel.media.cover_image) {
                    slideImages = [config.hotel.media.cover_image];
                }
            } catch (e) { }
        }
    }

    if (slideImages.length === 0) {
        slideImages = ['images/main.jpg'];
    }

    const slides = document.querySelectorAll('#bg-slider .slide');
    if (slides.length < 2) return;

    // Show main.jpg immediately, then upgrade to external images if they load
    slides[0].style.backgroundImage = "url('images/main.jpg')";
    slides[0].classList.add('active');
    slides[1].classList.remove('active');
    if (slideImages[0] && slideImages[0] !== 'images/main.jpg') {
        const tempImg1 = new Image();
        tempImg1.onload = () => {
            slides[0].style.backgroundImage = `url('${slideImages[0]}')`;
        };
        tempImg1.src = slideImages[0];
    }

    currentImageIndex = 0;
    activeSlideIndex = 0;

    if (slideImages.length > 1) {
        sliderIntervalId = setInterval(() => {
            currentImageIndex = (currentImageIndex + 1) % slideImages.length;
            const nextSlideIndex = activeSlideIndex === 0 ? 1 : 0;
            const targetUrl = slideImages[currentImageIndex];

            // Validate image loads successfully before transitioning
            const tempImgNext = new Image();
            tempImgNext.onload = () => {
                slides[nextSlideIndex].style.backgroundImage = `url('${targetUrl}')`;
                slides[nextSlideIndex].classList.add('active');
                slides[activeSlideIndex].classList.remove('active');
                activeSlideIndex = nextSlideIndex;
            };
            tempImgNext.onerror = () => {
                console.warn(`Failed to load slider image: ${targetUrl}. Falling back to default.`);
                slides[nextSlideIndex].style.backgroundImage = "url('images/main.jpg')";
                slides[nextSlideIndex].classList.add('active');
                slides[activeSlideIndex].classList.remove('active');
                activeSlideIndex = nextSlideIndex;
            };
            tempImgNext.src = targetUrl;
        }, 5000);
    }
}

async function initLanguage() {
    try {
        // Load dynamic hotel configuration instantly from cache if available
        const cachedConfig = typeof window.getFastConfig === 'function' ? window.getFastConfig() : null;
        if (cachedConfig) {
            const devObj = cachedConfig.device || (cachedConfig.data && cachedConfig.data.device) || {};
            if (devObj.room_no) localStorage.setItem('roomNo', devObj.room_no);
            const devId = devObj.device_id || devObj.serial || localStorage.getItem('deviceSerial');
            if (devId) {
                const devIdEl = document.getElementById('cornerDeviceId');
                if (devIdEl) devIdEl.textContent = devId;
            }
            if (cachedConfig.hotel && cachedConfig.hotel.hotel_name) {
                document.title = cachedConfig.hotel.hotel_name;
            }
            if (cachedConfig.hotel && cachedConfig.hotel.active_plan) {
                checkPlanStatus(cachedConfig.hotel.active_plan);
            }
            if (cachedConfig.hotel && cachedConfig.hotel.media && cachedConfig.hotel.media.slider_images) {
                initSlider(cachedConfig.hotel.media.slider_images);
            } else {
                initSlider([]);
            }
            applyDynamicMenuVisibility(cachedConfig);
        } else {
            initSlider([]);
        }

        // Run updated fetch in the background to avoid blocking initial render
        fetchHotelConfig().then(config => {
            if (config) {
                const devObj = config.device || (config.data && config.data.device) || {};
                if (devObj.room_no) localStorage.setItem('roomNo', devObj.room_no);
                const devId = devObj.device_id || devObj.serial || localStorage.getItem('deviceSerial');
                if (devId) {
                    const devIdEl = document.getElementById('cornerDeviceId');
                    if (devIdEl) devIdEl.textContent = devId;
                }
                if (config.hotel && config.hotel.hotel_name) {
                    document.title = config.hotel.hotel_name;
                }
                if (config.hotel && config.hotel.active_plan) {
                    checkPlanStatus(config.hotel.active_plan);
                }
                if (config.hotel && config.hotel.media && config.hotel.media.slider_images) {
                    initSlider(config.hotel.media.slider_images);
                }
                applyDynamicMenuVisibility(config);
                updateGreetingDisplay();
            }
        }).catch(err => console.warn("Background fetch failed:", err));

        const langFile = localStorage.getItem('selectedLangFile') || 'english.json';
        const response = await fetch(`languages/${langFile}?t=${Date.now()}`).catch(() => null);
        if (response && response.ok) {
            const freshData = await response.json();
            currentData = { ...currentData, ...freshData };
            if (currentData.direction === 'rtl') {
                document.body.classList.add('rtl-mode');
            } else {
                document.body.classList.remove('rtl-mode');
            }
        }
    } catch (e) { console.error("Initialization failed:", e); }
    finally {
        applyTranslations();
        updateDateTime();
        updateWeather();
        fetchGuestData();
        // Clean up legacy sticky localStorage items
        localStorage.removeItem("lastFocusedLabel");
        localStorage.removeItem("lastFocusedAction");

        // Restore last focused item (Default to Hotel Info on boot/refresh)
        var lastLabel = sessionStorage.getItem("lastFocusedLabel") || "Hotel Info";
        var lastAction = sessionStorage.getItem("lastFocusedAction") || "hotel_info";
        if (track) {
            // Disable transition temporarily to prevent sliding animation on page load
            var originalTransition = track.style.transition;
            track.style.transition = 'none';

            var visibleIcons = Array.prototype.slice.call(track.querySelectorAll(".icon-item")).filter(function (el) {
                return el.style.display !== 'none' && window.getComputedStyle(el).display !== 'none';
            });

            var targetIndex = -1;
            for (var j = 0; j < visibleIcons.length; j++) {
                var item = visibleIcons[j];
                var labelEl = item.querySelector(".icon-label");
                var labelText = labelEl ? labelEl.innerText.trim().toLowerCase() : "";
                var actionAttr = (item.getAttribute('data-action') || item.getAttribute('data-link') || item.getAttribute('href') || "").toLowerCase();

                if ((lastAction && actionAttr.indexOf(lastAction.toLowerCase()) !== -1) ||
                    (lastLabel && labelText === lastLabel.trim().toLowerCase())) {
                    targetIndex = j;
                    break;
                }
            }

            if (targetIndex !== -1) {
                var diff = targetIndex - centerIndex;
                if (diff > 0) {
                    for (var i = 0; i < diff; i++) {
                        var firstVis = track.querySelector('.icon-item:not([style*="display: none"])');
                        if (firstVis) track.appendChild(firstVis);
                    }
                } else if (diff < 0) {
                    for (var k = 0; k < Math.abs(diff); k++) {
                        var vItems = Array.prototype.slice.call(track.querySelectorAll('.icon-item')).filter(function (el) {
                            return el.style.display !== 'none' && window.getComputedStyle(el).display !== 'none';
                        });
                        var lastVis = vItems[vItems.length - 1];
                        if (lastVis) track.insertBefore(lastVis, track.firstElementChild);
                    }
                }
            }

            updateCarouselPosition();

            // Force a DOM reflow to make the positioning instant before re-enabling transition
            void track.offsetHeight;

            // Restore transition for D-pad navigation
            track.style.transition = originalTransition;
        } else {
            updateCarouselPosition();
        }

        setTimeout(function () {
            syncFocus();
            // Bind click event: if a non-centered item is clicked by mouse, center it first
            if (track) {
                track.querySelectorAll('.icon-item').forEach(function (item) {
                    item.addEventListener('click', function (e) {
                        var visibleItems = Array.prototype.slice.call(track.querySelectorAll('.icon-item')).filter(function (el) {
                            return el.style.display !== 'none' && window.getComputedStyle(el).display !== 'none';
                        });
                        var index = visibleItems.indexOf(this);
                        if (index !== centerIndex) {
                            e.preventDefault();
                            e.stopPropagation();
                            rotateToItem(this);
                        }
                    }, true);
                });
            }
        }, 300);
    }
}

function applyDynamicMenuVisibility(config) {
    if (!config || !config.menus || !Array.isArray(config.menus)) return;

    // Map menu IDs to HTML data-action or data-link keys
    const menuMap = {
        'apps': 'apps',
        'applications': 'apps',
        'live_tv': 'livetv',
        'livetv': 'livetv',
        'input': 'input',
        'screen_cast': 'cast',
        'cast': 'cast',
        'refresh': 'refresh',
        'languages': 'languages.html',
        'languages.html': 'languages.html',
        'hotel_info': './hotel_info/hotel_info_menu.html',
        'amenities': './amenities/amenities.html',
        'travel': './travel/travel.html',
        'flights': './flights/flights.html',
        'our_city': './city/city.html',
        'city': './city/city.html',
        'weather': './weather/weather.html',
        'settings': './settings.html'
    };

    config.menus.forEach(menu => {
        if (!menu || !menu.id) return;
        const targetAttr = menuMap[menu.id] || menu.id;
        const status = (menu.status || '').toLowerCase();

        document.querySelectorAll('.icon-item').forEach(item => {
            const action = item.getAttribute('data-action');
            const link = item.getAttribute('data-link') || item.getAttribute('href');

            if (action === targetAttr || link === targetAttr) {
                if (status === 'hide' || status === 'disabled' || status === '0' || status === 'false') {
                    item.style.display = 'none';
                } else {
                    item.style.display = '';
                }
            }
        });
    });

    if (window.TVNavigation && typeof window.TVNavigation.markDirty === 'function') {
        window.TVNavigation.markDirty();
    }
    syncFocus();
}

function applyTranslations() {
    const roomNo = localStorage.getItem('roomNo') || "";
    const roomEl = document.getElementById('room');
    if (roomEl) roomEl.textContent = `${currentData.room_label} ${roomNo}`;

    const iconMap = {
        'apps': 'applications',
        'livetv': 'live_tv',
        'input': 'input',
        'cast': 'screen_cast',
        'refresh': 'refresh',
        'languages.html': 'language',
        './languages.html': 'language',
        'hotel_info/hotel_info.html': 'hotel_info',
        './hotel_info/hotel_info.html': 'hotel_info',
        'hotel_info/hotel_info_menu.html': 'hotel_info',
        './hotel_info/hotel_info_menu.html': 'hotel_info',
        'amenities/amenities.html': 'amenities',
        './amenities/amenities.html': 'amenities',
        'travel/travel.html': 'travel',
        './travel/travel.html': 'travel',
        'city/city.html': 'our_city',
        './city/city.html': 'our_city',
        'weather/weather.html': 'weather',
        './weather/weather.html': 'weather',
        'settings.html': 'settings',
        './settings.html': 'settings',
        'flights/flights.html': 'flights',
        './flights/flights.html': 'flights'
    };

    document.querySelectorAll('.icon-item').forEach(item => {
        const key = item.getAttribute('data-link') || item.getAttribute('data-action');
        const labelEl = item.querySelector('.icon-label');
        const jsonKey = iconMap[key];
        if (labelEl && jsonKey) {
            let translated = null;
            if (currentData.icons && currentData.icons[jsonKey]) {
                translated = currentData.icons[jsonKey];
            } else if (currentData[jsonKey]) {
                translated = currentData[jsonKey];
            }
            if (translated) {
                labelEl.textContent = translated;
            }
        }
    });

    // Also re-apply dynamic menu visibility from cached config if available
    try {
        const cached = localStorage.getItem('cachedHotelData');
        if (cached) {
            applyDynamicMenuVisibility(JSON.parse(cached));
        }
    } catch (e) { }
}

function fetchGuestData() {
    const roomNo = localStorage.getItem('roomNo') || "";
    if (!roomNo) return;
    fetch(`admin/rooms.json?t=` + new Date().getTime())
        .then(res => res.json())
        .then(allRooms => {
            const roomData = allRooms[roomNo] || allRooms["_default"];
            if (roomData && roomData.guest_name) {
                const langKey = (currentData.language_name) ? currentData.language_name.toLowerCase() : "english";
                let localizedName = roomData.guest_name[langKey] || roomData.guest_name["english"] || "Guest";
                window.guestName = localizedName;
                updateGreetingDisplay();
            }
        }).catch(e => { });
}

function updateDateTime() {
    const now = new Date();
    const isRTL = document.body.classList.contains('rtl-mode');

    // Set Time - uses local system clock (no NTP)
    const timeEl = document.getElementById('time');
    if (timeEl) timeEl.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

    // Set Room
    const roomNo = localStorage.getItem('roomNo') || "";
    const roomEl = document.getElementById('room');
    if (roomEl) roomEl.textContent = `${currentData.room_label} ${roomNo}`;

    // Set Date with RTL comma
    const dateEl = document.getElementById('date');
    if (dateEl) {
        const dayKey = now.toLocaleDateString('en-US', { weekday: 'short' }).toLowerCase();
        const monthKey = now.toLocaleDateString('en-US', { month: 'short' }).toLowerCase();
        const dayName = (currentData.days && currentData.days[dayKey]) || "";
        const monthName = (currentData.months && currentData.months[monthKey]) || "";

        dateEl.textContent = isRTL
            ? `${dayName}، ${now.getDate()} ${monthName}`
            : `${dayName}, ${monthName} ${now.getDate()}`;
    }
    updateGreetingDisplay();
}

function updateGreetingDisplay() {
    const hour = new Date().getHours();
    let msg = currentData.greetings.night;
    if (hour < 12) msg = currentData.greetings.morning;
    else if (hour < 17) msg = currentData.greetings.afternoon;
    else if (hour < 21) msg = currentData.greetings.evening;

    const greetEl = document.getElementById('greeting');
    if (!greetEl) return;

    var cfg = typeof window.getFastConfig === 'function' ? window.getFastConfig() : null;
    let guest = "Guest";
    if (cfg && cfg.guest_info && cfg.guest_info.name) {
        guest = cfg.guest_info.name;
    } else if (window.guestName) {
        guest = window.guestName;
    }

    const comma = (currentData.direction === 'rtl') ? "، " : ", ";
    var text = msg + comma + guest;

    greetEl.textContent = text;
}

async function fetchCoordinates(city) {
    if (!navigator.onLine) {
        return {
            lat: 19.0760,
            lon: 72.8777,
            timezone: "Asia/Kolkata"
        };
    }
    try {
        const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`;
        const res = await fetch(geoUrl);
        if (res.ok) {
            const data = await res.json();
            if (data && data.results && data.results.length > 0) {
                return {
                    lat: data.results[0].latitude,
                    lon: data.results[0].longitude,
                    timezone: data.results[0].timezone || "auto"
                };
            }
        }
    } catch (e) {
        console.warn("Geocoding lookup failed, using fallback coordinates:", e);
    }
    return {
        lat: 19.0760,
        lon: 72.8777,
        timezone: "Asia/Kolkata"
    };
}

async function fetchIpLocation() {
    if (!navigator.onLine) {
        return null;
    }
    const cachedIpCity = localStorage.getItem('cached_ip_city');
    const cachedIpTime = parseInt(localStorage.getItem('cached_ip_city_time') || '0');
    if (cachedIpCity && (Date.now() - cachedIpTime < 24 * 60 * 60 * 1000)) {
        return cachedIpCity;
    }

    try {
        const res = await fetch('https://ipinfo.io/json');
        if (res.ok) {
            const data = await res.json();
            if (data && data.city) {
                localStorage.setItem('cached_ip_city', data.city);
                localStorage.setItem('cached_ip_city_time', Date.now().toString());
                return data.city;
            }
        }
    } catch (e) {
        console.warn("ipinfo.io failed, trying fallback:", e);
    }
    try {
        const res = await fetch('https://ipapi.co/json/');
        if (res.ok) {
            const data = await res.json();
            if (data && data.city) {
                localStorage.setItem('cached_ip_city', data.city);
                localStorage.setItem('cached_ip_city_time', Date.now().toString());
                return data.city;
            }
        }
    } catch (e) {
        console.warn("ipapi.co failed:", e);
    }
    return null;
}

async function resolveLocation() {
    // 1. data.json (city or hotel_location) takes highest priority
    try {
        let config = typeof window.getFastConfig === 'function' ? window.getFastConfig() : null;
        if (!config && typeof fetchHotelConfig === 'function') {
            config = await fetchHotelConfig();
        }
        if (config && config.hotel) {
            const loc = config.hotel.city;
            if (loc) {
                localStorage.setItem('weather_city', loc);
                return loc;
            }
        }
    } catch (e) {
        console.warn("Failed resolving hotel city/location", e);
    }

    // 2. Fallback to cached city from previous sessions
    let cachedCity = localStorage.getItem('weather_city');
    if (cachedCity) return cachedCity;

    // 3. IP Geolocation fallback (Only if device is online)
    if (navigator.onLine) {
        try {
            if (typeof fetchIpLocation === 'function') {
                const ipCity = await fetchIpLocation();
                if (ipCity) {
                    localStorage.setItem('weather_city', ipCity);
                    return ipCity;
                }
            }
        } catch (e) {
            console.warn("Failed fetching IP location fallback:", e);
        }
    }

    // 4. Ultimate Fallback
    return "Mumbai";
}

async function updateWeather() {
    const tempEl = document.getElementById('temp');
    if (!tempEl) return;
    if (!navigator.onLine) {
        console.warn("Weather: Device is offline. Hiding weather display.");
        tempEl.textContent = "";
        return;
    }

    try {
        const city = await resolveLocation();
        const coords = await fetchCoordinates(city);

        const url = `https://api.open-meteo.com/v1/forecast?latitude=${coords.lat}&longitude=${coords.lon}&current=temperature_2m&timezone=${encodeURIComponent(coords.timezone)}`;
        const response = await fetch(url);
        if (!response.ok) throw new Error("Open-Meteo Forecast Request failed");

        const data = await response.json();
        const tempC = Math.round(data.current.temperature_2m);
        const tempF = Math.round((tempC * 9 / 5) + 32);
        const tempString = `${tempC}°C / ${tempF}°F`;

        const isRTL = document.body.classList.contains('rtl-mode');
        if (isRTL) {
            tempEl.textContent = `${tempString} ${city}`;
            tempEl.style.direction = 'rtl';
        } else {
            tempEl.textContent = `${city} ${tempString}`;
            tempEl.style.direction = 'ltr';
        }

        localStorage.setItem('cached_temp_string', tempString);
        localStorage.setItem('cached_temp_city', city);

    } catch (error) {
        console.error("Weather Update Error:", error);
        const cachedTemp = localStorage.getItem('cached_temp_string');
        const cachedCity = localStorage.getItem('cached_temp_city');
        if (cachedTemp && cachedCity) {
            const isRTL = document.body.classList.contains('rtl-mode');
            tempEl.textContent = isRTL ? `${cachedTemp} ${cachedCity}` : `${cachedCity} ${cachedTemp}`;
            tempEl.style.direction = isRTL ? 'rtl' : 'ltr';
            return;
        }

        // Try local fallback file weather/weather_data.json
        try {
            const response = await fetch('weather/weather_data.json?v=' + Date.now());
            if (response.ok) {
                const data = await response.json();
                const city = await resolveLocation();
                const tempC = Math.round(data.extracted_data.temp);
                const tempF = Math.round((tempC * 9 / 5) + 32);
                const tempString = `${tempC}°C / ${tempF}°F`;
                const isRTL = document.body.classList.contains('rtl-mode');
                tempEl.textContent = isRTL ? `${tempString} ${city}` : `${city} ${tempString}`;
                tempEl.style.direction = isRTL ? 'rtl' : 'ltr';
            }
        } catch (fallbackErr) {
            console.warn("Local fallback load failed on home page:", fallbackErr);
        }
    }
}

let allCitiesList = [];
async function loadCitiesList() {
    try {
        const langFile = localStorage.getItem('selectedLangFile') || 'english.json';
        const langName = langFile.replace('.json', '');
        const response = await fetch(`admin/cities/${langName}_cities.json`);
        if (response.ok) {
            allCitiesList = await response.json();
        } else {
            const fallbackRes = await fetch('admin/cities/english_cities.json');
            if (fallbackRes.ok) {
                allCitiesList = await fallbackRes.json();
            }
        }
    } catch (e) {
        console.warn("Failed to load cities list", e);
    }
}

/* ================= 4. COMING SOON ================= */
var comingSoonLinks = ['./travel/travel.html', './city/city.html'];

/* ================= 5. LISTENERS ================= */
function showExpiredOverlay() {
    var overlay = document.getElementById('planExpiredOverlay');
    if (!overlay) return;
    overlay.style.display = 'flex';
}

function showWarningToast(daysLeft) {
    var toast = document.getElementById('planWarningToast');
    var body = document.getElementById('planWarningBody');
    if (!toast || !body) return;
    body.innerHTML = 'Your plan will expire in <strong>' + daysLeft + ' day' + (daysLeft > 1 ? 's' : '') + '</strong>. Please renew to avoid interruption.';
    toast.style.display = 'block';
    setTimeout(function () {
        toast.style.display = 'none';
    }, 10000);
}

function checkPlanStatus(plan) {
    if (!plan || !plan.expiry_date) return;
    var now = new Date();
    var expiry = new Date(plan.expiry_date);
    if (isNaN(expiry.getTime())) {
        var parts = plan.expiry_date.split('T')[0].split('-');
        expiry = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
    }
    var diff = Math.ceil((expiry - now) / (1000 * 60 * 60 * 24));
    if (diff <= 0) {
        showExpiredOverlay();
    } else if (diff <= 5) {
        showWarningToast(diff);
    }
}

window.onload = function () {
    try {
        var bg = document.getElementById('bg-slider');
        if (bg && !bg.style.backgroundImage) {
            bg.style.backgroundImage = "url('images/main.jpg')";
        }
        initLanguage();
        setInterval(updateDateTime, 1000);
        setInterval(updateWeather, 900000); // Check weather every 15 minutes

        // Auto-focus synchronization for subpages loaded inside the iframe
        var subFrame = document.getElementById('subFrame');
        if (subFrame) {
            subFrame.addEventListener('load', function () {
                try {
                    if (subFrame.contentWindow) {
                        subFrame.contentWindow.focus();
                        if (subFrame.contentWindow.TVNavigation) {
                            subFrame.contentWindow.TVNavigation.handleInitialFocus();
                        }
                    }
                } catch (e) {
                    console.warn("Iframe focus sync error:", e);
                }
            });
        }

    } catch (e) {
        console.error('Initialization failed:', e);
    }
};        // --- 1. PREVENT ANDROID EXIT (Original Logic) ---
window.history.pushState(null, "", window.location.href);
window.onpopstate = function () {
    var comingSoon = document.getElementById('comingSoonOverlay');
    if (comingSoon && comingSoon.style.display === 'flex') {
        comingSoon.style.display = 'none';
        window.history.pushState(null, "", window.location.href);
        return;
    }
    var appsOverlay = document.getElementById('appsOverlay');
    if (appsOverlay && appsOverlay.classList.contains('show')) {
        closeAppsOverlay();
        window.history.pushState(null, "", window.location.href);
        return;
    }
    var overlay = document.getElementById('subPageOverlay');
    if (overlay.style.display === 'block') {
        closeSubPage();
        window.history.pushState(null, "", window.location.href);
    } else {
        window.history.pushState(null, "", window.location.href);
    }
};


function openSubPage(url) {
    var overlay = document.getElementById('subPageOverlay');
    if (!overlay) return;
    document.getElementById('subFrame').src = url;
    overlay.style.display = 'block';
    document.getElementById('mainUI').style.display = 'none';
    window.history.pushState(null, "", window.location.href);
    var subFrame = document.getElementById('subFrame');
    if (subFrame) {
        subFrame.focus();
        try {
            if (subFrame.contentWindow) {
                subFrame.contentWindow.focus();
            }
        } catch (e) { }
    }
}
window.openSubPage = openSubPage;

function closeSubPage() {
    document.getElementById('subPageOverlay').style.display = 'none';
    document.getElementById('subFrame').src = "";
    document.getElementById('mainUI').style.display = 'block';
    var items = document.querySelectorAll('.icon-item');
    if (items[3]) items[3].focus();
}

// =============================================================
// APPLICATIONS OVERLAY (Apps + TV Inputs)
// =============================================================

var DEFAULT_APP_ICON = 'images/icons/apps.png';

async function loadApplications() {
    var container = document.getElementById('apps-container');
    if (!container) return;
    container.innerHTML = '<div style="color:#888;font-size:1.2vw;grid-column:1/-1;text-align:center;">Loading...</div>';

    try {
        var bridge = window.flutterBridge;
        var apps = await bridge.getInstalledApps();
        if (!apps || apps.length === 0) throw new Error('No apps');

        container.innerHTML = '';
        apps.forEach(function (app) {
            var pkg = app.packageName || app.package || app.id || '';
            var name = app.name || app.label || pkg;
            var icon = app.icon || '';

            var card = document.createElement('div');
            card.className = 'app-card';
            card.tabIndex = 0;
            card.setAttribute('data-package', pkg);

            var img = document.createElement('img');
            img.src = icon || DEFAULT_APP_ICON;
            img.alt = name;
            img.onerror = function () { this.src = DEFAULT_APP_ICON; };

            var label = document.createElement('div');
            label.className = 'app-name';
            label.textContent = name;

            card.appendChild(img);
            card.appendChild(label);

            card.addEventListener('click', function () {
                var p = this.getAttribute('data-package');
                if (p && window.flutterBridge && window.flutterBridge.launchApp) {
                    window.flutterBridge.launchApp(p)['catch'](function (err) {
                        console.error('Launch app failed:', err);
                    });
                }
            });
            card.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' || e.keyCode === 13) {
                    this.click();
                }
            });

            container.appendChild(card);
        });

        // Mark focus cache dirty and focus the first card once rendered
        if (window.TVNavigation && typeof window.TVNavigation.markDirty === 'function') {
            window.TVNavigation.markDirty();
        }
        var firstCard = container.querySelector('.app-card');
        if (firstCard) {
            var allFocus = document.querySelectorAll('.active-focus');
            for (var k = 0; k < allFocus.length; k++) {
                allFocus[k].classList.remove('active-focus');
            }
            firstCard.focus();
            firstCard.classList.add('active-focus');
        }
    } catch (e) {
        container.innerHTML = '<div style="color:#888;font-size:1.2vw;grid-column:1/-1;text-align:center;">No applications available</div>';
        console.error('loadApplications error:', e);
    }
}

async function loadTvInputs() {
    var container = document.getElementById('tv-inputs-container') || document.getElementById('direct-tv-inputs-container');
    if (!container) return;

    try {
        container.innerHTML = '<div style="color:#888;font-size:1.1vw;">Detecting TV ports...</div>';
        var bridge = window.flutterBridge;
        var inputs = (bridge && typeof bridge.getTvInputs === 'function') 
            ? await bridge.getTvInputs() 
            : [];

        if (!inputs || inputs.length === 0) {
            container.innerHTML = '<div style="color:#888;font-size:1.1vw;">No active TV ports found</div>';
            return;
        }

        var savedPort = localStorage.getItem('selectedLiveTvPort') || localStorage.getItem('selectedHdmiPort') || '';

        container.innerHTML = '';
        inputs.forEach(function (input) {
            var btn = document.createElement('button');
            btn.className = 'tv-input-btn focusable';
            btn.tabIndex = 0;

            // 1. Display text as real physical port name (e.g. "HDMI 1", "HDMI 2", "AV Input", "Live TV (Tuner)")
            var displayLabel = input.label || input.name || input.id || 'HDMI';
            btn.textContent = displayLabel;

            // 2. Set target hardware port ID
            var targetPortId = input.id || input.model || displayLabel;
            btn.setAttribute('data-port-id', targetPortId);

            // 3. Highlight currently selected preferred port
            if (savedPort && (targetPortId.toLowerCase() === savedPort.toLowerCase() || displayLabel.toLowerCase() === savedPort.toLowerCase())) {
                btn.style.border = '2px solid #b38a2d';
                btn.style.background = 'rgba(179,138,45,0.2)';
                btn.style.boxShadow = 'inset 0 0 8px rgba(179,138,45,0.5)';
            }

            // 4. On click, save preference and launch hardware input
            btn.addEventListener('click', function () {
                var selectedPort = this.getAttribute('data-port-id');
                if (selectedPort) {
                    try {
                        localStorage.setItem('selectedLiveTvPort', selectedPort);
                        localStorage.setItem('selectedHdmiPort', selectedPort);
                    } catch (_) {}
                }
                closeAppsOverlay();
                if (window.flutterBridge && typeof window.flutterBridge.launchHdmi === 'function') {
                    window.flutterBridge.launchHdmi(selectedPort).catch(function (err) {
                        console.error('Failed to launch TV port:', err);
                    });
                }
            });

            btn.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' || e.keyCode === 13) {
                    this.click();
                }
            });

            container.appendChild(btn);
        });

        // Focus the first or selected input button for TV remote navigation
        if (window.TVNavigation && typeof window.TVNavigation.markDirty === 'function') {
            window.TVNavigation.markDirty();
        }
        var targetToFocus = container.querySelector('.tv-input-btn');
        if (targetToFocus) {
            var allFocus = document.querySelectorAll('.active-focus');
            for (var k = 0; k < allFocus.length; k++) {
                allFocus[k].classList.remove('active-focus');
            }
            targetToFocus.focus();
            targetToFocus.classList.add('active-focus');
        }
    } catch (e) {
        container.innerHTML = '<div style="color:#888;font-size:1.1vw;">No active TV ports found</div>';
        console.error('loadTvInputs error:', e);
    }
}

function openAppsOverlay() {
    var overlay = document.getElementById('appsOverlay');
    if (!overlay) return;

    // Clear active-focus from main UI items
    var allFocus = document.querySelectorAll('.active-focus');
    for (var i = 0; i < allFocus.length; i++) {
        allFocus[i].classList.remove('active-focus');
    }

    overlay.classList.add('show');
    document.body.classList.add('overlay-active');
    document.getElementById('mainUI').style.display = 'none';
    window.history.pushState(null, "", window.location.href);
    window.__appsOverlayOpen = true;

    var appsTitle = overlay.querySelector('.apps-title');
    if (appsTitle) appsTitle.textContent = 'Applications';

    var section = document.getElementById('tv-inputs-section');
    if (section) section.style.display = 'none';

    var container = document.getElementById('tv-inputs-container');
    if (container) container.style.display = 'none';

    document.getElementById('apps-container').style.display = '';

    loadApplications();

    setTimeout(function () {
        var firstCard = document.querySelector('.app-card');
        if (firstCard) {
            firstCard.focus();
            firstCard.classList.add('active-focus');
        }
    }, 200);
}

async function openLiveTVOverlay() {
    // Direct launch active connected TV setup box port / Live TV
    try {
        if (window.flutterBridge && typeof window.flutterBridge.launchLiveTv === 'function') {
            window.flutterBridge.launchLiveTv().catch(function (err) {
                console.warn('launchLiveTv warning:', err);
            });
            return;
        } else if (window.flutterBridge && typeof window.flutterBridge.launchHdmi === 'function') {
            window.flutterBridge.launchHdmi().catch(function (err) {
                console.warn('launchHdmi warning:', err);
            });
            return;
        }
    } catch (e) {
        console.warn('Live TV bridge call warning:', e);
    }

    // For Live TV Menu Click: connected Set-top box / Dish TV port check fallback
    if (window.flutterBridge && window.flutterBridge.getLiveTvInputs) {
        try {
            var liveTvInputs = await window.flutterBridge.getLiveTvInputs();
            if (liveTvInputs && liveTvInputs.length === 1) {
                // Agar 1 connected STB input hai, toh Direct launch ho jayega
                var targetId = liveTvInputs[0].id || liveTvInputs[0].model || liveTvInputs[0].label;
                if (targetId && window.flutterBridge.launchHdmi) {
                    window.flutterBridge.launchHdmi(targetId).catch(function (err) {
                        console.warn('Launch Live TV HDMI warning:', err);
                    });
                    return;
                }
            }
        } catch (e) {
            console.warn('getLiveTvInputs check failed:', e);
        }
    }

    var overlay = document.getElementById('appsOverlay');
    if (!overlay) return;

    // Clear active-focus from main UI items
    var allFocus = document.querySelectorAll('.active-focus');
    for (var j = 0; j < allFocus.length; j++) {
        allFocus[j].classList.remove('active-focus');
    }

    overlay.classList.add('show');
    document.body.classList.add('overlay-active');
    document.getElementById('mainUI').style.display = 'none';
    window.history.pushState(null, "", window.location.href);
    window.__appsOverlayOpen = true;

    var appsTitle = overlay.querySelector('.apps-title');
    if (appsTitle) appsTitle.textContent = 'Live TV';

    var section = document.getElementById('tv-inputs-section');
    if (section) section.style.display = '';

    var container = document.getElementById('tv-inputs-container');
    if (container) container.style.display = '';

    document.getElementById('apps-container').style.display = 'none';

    loadTvInputs();

    setTimeout(function () {
        var firstInput = document.querySelector('.tv-input-btn');
        if (firstInput) {
            firstInput.focus();
            firstInput.classList.add('active-focus');
        }
    }, 200);
}

function closeAppsOverlay() {
    var overlay = document.getElementById('appsOverlay');
    if (!overlay) return;
    overlay.classList.remove('show');
    document.body.classList.remove('overlay-active');
    window.__appsOverlayOpen = false;
    document.getElementById('mainUI').style.display = 'block';
    var items = document.querySelectorAll('.icon-item');
    if (items[3]) items[3].focus();
}



document.getElementById('appsCloseBtn').addEventListener('click', function () {
    closeAppsOverlay();
    window.history.pushState(null, "", window.location.href);
});

function openInputOverlay() {
    var overlay = document.getElementById('inputOverlay');
    if (!overlay) return;

    overlay.style.display = 'flex';
    document.body.classList.add('overlay-active');
    document.getElementById('mainUI').style.display = 'none';
    window.history.pushState(null, "", window.location.href);
    window.__inputOverlayOpen = true;

    var container = document.getElementById('direct-tv-inputs-container');
    if (container) {
        container.innerHTML = '<div style="color:#ffd700;font-size:20px;font-weight:600;padding:20px;">Loading inputs...</div>';
    }

    function renderFallbackInputs() {
        if (!container) return;
        container.innerHTML = '';
        var fallbackList = [
            { label: 'Setup Box (HDMI 1)', id: 'HDMI 1' },
            { label: 'HDMI 2', id: 'HDMI 2' },
            { label: 'AV Input', id: 'AV' }
        ];
        fallbackList.forEach(function (input) {
            var btn = document.createElement('button');
            btn.className = 'tv-input-btn focusable';
            btn.tabIndex = 0;
            btn.textContent = input.label;
            btn.setAttribute('data-model', input.id);
            btn.addEventListener('click', function () {
                var model = this.getAttribute('data-model');
                closeInputOverlay();
                if (window.flutterBridge && window.flutterBridge.launchHdmi) {
                    window.flutterBridge.launchHdmi(model).catch(function (err) {
                        console.error('Launch HDMI failed:', err);
                    });
                }
            });
            container.appendChild(btn);
        });
        if (window.TVNavigation && typeof window.TVNavigation.markDirty === 'function') {
            window.TVNavigation.markDirty();
        }
        var firstBtn = container.querySelector('.tv-input-btn');
        if (firstBtn) firstBtn.focus();
    }

    if (window.flutterBridge && typeof window.flutterBridge.getTvInputs === 'function') {
        window.flutterBridge.getTvInputs().then(function (inputs) {
            if (!container) return;
            if (!inputs || inputs.length === 0) {
                renderFallbackInputs();
                return;
            }
            container.innerHTML = '';
            inputs.forEach(function (input) {
                var btn = document.createElement('button');
                btn.className = 'tv-input-btn focusable';
                btn.tabIndex = 0;
                var label = input.label || input.id || 'HDMI';
                btn.textContent = label;
                var modelId = input.id || '';
                btn.setAttribute('data-model', modelId);

                btn.addEventListener('click', function () {
                    var model = this.getAttribute('data-model') || label;
                    closeInputOverlay();
                    try {
                        if (window.flutterBridge && typeof window.flutterBridge.launchHdmi === 'function') {
                            window.flutterBridge.launchHdmi(model).catch(function (err) {
                                console.warn('Launch HDMI warning:', err);
                            });
                        }
                    } catch (e) {
                        console.warn('launchHdmi bridge exception:', e);
                    }
                });
                container.appendChild(btn);
            });
            if (window.TVNavigation && typeof window.TVNavigation.markDirty === 'function') {
                window.TVNavigation.markDirty();
            }
            var firstInput = container.querySelector('.tv-input-btn');
            if (firstInput) firstInput.focus();
        }).catch(function () {
            renderFallbackInputs();
        });
    } else {
        renderFallbackInputs();
    }

    setTimeout(function () {
        if (window.TVNavigation && typeof window.TVNavigation.markDirty === 'function') {
            window.TVNavigation.markDirty();
        }
        var btn = document.getElementById('inputCloseBtn');
        if (btn) btn.focus();
    }, 150);
}

function closeInputOverlay() {
    var overlay = document.getElementById('inputOverlay');
    if (!overlay) return;
    overlay.style.display = 'none';
    document.body.classList.remove('overlay-active');
    window.__inputOverlayOpen = false;
    document.getElementById('mainUI').style.display = 'block';
    var items = document.querySelectorAll('.icon-item');
    if (items[3]) items[3].focus();
}

async function openCastOverlay() {
    // 1. Open Overlay Immediately so UI is instant & responsive
    const overlay = document.getElementById('castOverlay');
    if (overlay) {
        overlay.style.display = 'flex';
        document.body.classList.add('overlay-active');
        var mainUI = document.getElementById('mainUI');
        if (mainUI) mainUI.style.display = 'none';
        window.history.pushState(null, "", window.location.href);
        window.__castOverlayOpen = true;
    }

    setTimeout(function () {
        if (window.TVNavigation && typeof window.TVNavigation.markDirty === 'function') {
            window.TVNavigation.markDirty();
        }
        var btn = document.getElementById('castCloseBtn');
        if (btn) btn.focus();
    }, 150);

    // 2. Native Screen Mirroring Trigger (Safe Bridge Guard)
    try {
        if (window.flutterBridge && typeof window.flutterBridge.launchCast === 'function') {
            var castRes = window.flutterBridge.launchCast();
            if (castRes && typeof castRes.catch === 'function') {
                castRes.catch(function (err) {
                    console.warn('Launch cast bridge warning:', err);
                });
            }
        }
    } catch (e) {
        console.warn('launchCast bridge not available on web:', e);
    }

    // 3. Fetch Device Info Dynamically
    let deviceName = 'Hotel TV';
    try {
        if (window.flutterBridge && typeof window.flutterBridge.identifyDevice === 'function') {
            let deviceInfo = window.flutterBridge.identifyDevice();
            if (deviceInfo && typeof deviceInfo.then === 'function') {
                deviceInfo = await deviceInfo;
            }
            if (typeof deviceInfo === 'string') {
                try { deviceInfo = JSON.parse(deviceInfo); } catch (err) {}
            }
            const data = (deviceInfo && (deviceInfo.data || deviceInfo.device || deviceInfo)) || {};
            deviceName = data.device_name || data.deviceName || data.name || (data.room_no ? `Hotel TV (Room ${data.room_no})` : 'Hotel TV');
        }
    } catch (e) {
        console.warn('Failed to fetch device info from bridge:', e);
    }

    // Fallback if deviceName was not resolved from bridge
    if (!deviceName || deviceName === 'Hotel TV') {
        var roomNo = localStorage.getItem('roomNo') || '';
        if (!roomNo && window.TVCore && typeof window.TVCore.getFastConfig === 'function') {
            var cfg = window.TVCore.getFastConfig();
            if (cfg && cfg.device && cfg.device.room_no) {
                roomNo = cfg.device.room_no;
            }
        }
        if (!roomNo) {
            const cached = localStorage.getItem('cachedHotelData');
            if (cached) {
                try {
                    const config = JSON.parse(cached);
                    roomNo = (config.device && config.device.room_no) || config.room_no || '';
                } catch (err) {}
            }
        }
        if (roomNo) {
            deviceName = `Hotel TV (Room ${roomNo})`;
        } else if (localStorage.getItem('deviceSerial')) {
            deviceName = `Hotel TV (${localStorage.getItem('deviceSerial')})`;
        }
    }

    // Update Device Name in Cast Modal UI
    const nameEl = document.getElementById('castDeviceName');
    if (nameEl) {
        nameEl.textContent = deviceName;
    }
}

function closeCastOverlay() {
    var overlay = document.getElementById('castOverlay');
    if (!overlay) return;
    overlay.style.display = 'none';
    document.body.classList.remove('overlay-active');
    window.__castOverlayOpen = false;
    document.getElementById('mainUI').style.display = 'block';
    var items = document.querySelectorAll('.icon-item');
    if (items[3]) items[3].focus();
}

function triggerManualRefresh() {
    // 1. Clear dynamic local storage & caches
    localStorage.removeItem('cachedHotelData');
    localStorage.removeItem('cached_temp_string');
    localStorage.removeItem('cached_ip_city');

    // 2. Show temporary feedback toast
    var toast = document.createElement('div');
    toast.style.position = 'fixed';
    toast.style.top = '20px';
    toast.style.right = '20px';
    toast.style.background = '#b38a2d';
    toast.style.color = '#fff';
    toast.style.padding = '12px 24px';
    toast.style.borderRadius = '8px';
    toast.style.zIndex = '99999';
    toast.style.fontWeight = 'bold';
    toast.style.boxShadow = '0 4px 12px rgba(0,0,0,0.5)';
    toast.textContent = 'Refreshing fresh data & APIs...';
    document.body.appendChild(toast);

    // 3. Re-fetch all APIs (Hotel Config, Guest Data, Weather, Check-Version)
    if (window.TVCore && typeof window.TVCore.fetchHotelConfig === 'function') {
        window.TVCore.fetchHotelConfig(true).then(function () {
            initLanguage();
            updateDateTime();
            updateWeather();
            fetchGuestData();
        });
    } else {
        initLanguage();
        updateDateTime();
        updateWeather();
        fetchGuestData();
    }

    // 4. Trigger Flutter Native Full WebView Page Reload
    if (window.flutterBridge && window.flutterBridge.refreshApp) {
        setTimeout(function () {
            window.flutterBridge.refreshApp();
        }, 500);
    }

    setTimeout(function () {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 2000);
}

document.getElementById('inputCloseBtn').addEventListener('click', closeInputOverlay);
document.getElementById('castCloseBtn').addEventListener('click', closeCastOverlay);

window.openInputOverlay = openInputOverlay;
window.closeInputOverlay = closeInputOverlay;
window.openCastOverlay = openCastOverlay;
window.closeCastOverlay = closeCastOverlay;

var comingSoonLinks = ['./travel/travel.html', './city/city.html'];

document.querySelectorAll('.icon-item').forEach(item => {
    item.addEventListener('click', function () {
        const action = this.getAttribute('data-action');

        if (action === "livetv") {
            if (typeof window.openLiveTVOverlay === 'function') window.openLiveTVOverlay();
            return;
        }
        if (action === "apps") {
            if (typeof window.openAppsOverlay === 'function') window.openAppsOverlay();
            return;
        }
        if (action === "input") {
            openInputOverlay();
            return;
        }
        if (action === "cast") {
            openCastOverlay();
            return;
        }
        if (action === "refresh") {
            triggerManualRefresh();
            return;
        }

        const link = this.dataset.link || this.getAttribute('href');

        // Internet connection check for Weather and Flights
        if (!navigator.onLine && (action === "weather" || (link && (link.includes("weather") || link.includes("flights"))))) {
            var noNetOverlay = document.getElementById('noInternetOverlay');
            if (noNetOverlay) {
                noNetOverlay.style.display = 'flex';
                setTimeout(function () {
                    var btn = document.getElementById('noInternetCloseBtn');
                    if (btn) btn.focus();
                }, 100);
            }
            return;
        }

        if (link && comingSoonLinks.indexOf(link) !== -1) {
            var overlay = document.getElementById('comingSoonOverlay');
            if (overlay) {
                overlay.style.display = 'flex';
                setTimeout(function () {
                    if (window.TVNavigation && typeof window.TVNavigation.markDirty === 'function') {
                        window.TVNavigation.markDirty();
                    }
                    var btn = overlay.querySelector('.cs-close-btn');
                    if (btn) {
                        btn.focus();
                        btn.classList.add('active-focus');
                    }
                }, 100);
            }
            return;
        }

        if (link) {
            window.location.href = link;
        }
    });
});

window.onTVKeyDown = function (e) {
    var comingSoon = document.getElementById("comingSoonOverlay");
    if (comingSoon && comingSoon.style.display === "flex") {
        e.preventDefault();
        comingSoon.style.display = "none";
        var items = document.querySelectorAll('.icon-item');
        if (items[3]) items[3].focus();
        return true;
    }
    return false;
};

window.onTVBack = function () {
    var inputOverlay = document.getElementById("inputOverlay");
    if (inputOverlay && inputOverlay.style.display === "flex") {
        closeInputOverlay();
        window.history.pushState(null, "", window.location.href);
        return true;
    }
    var castOverlay = document.getElementById("castOverlay");
    if (castOverlay && castOverlay.style.display === "flex") {
        closeCastOverlay();
        window.history.pushState(null, "", window.location.href);
        return true;
    }
    var citySelector = document.getElementById("citySelectorOverlay");
    if (citySelector && citySelector.style.display === "flex") {
        citySelector.style.display = "none";
        window.__citySelectorOpen = false;
        var tempEl = document.getElementById('temp');
        if (tempEl) {
            tempEl.focus();
            tempEl.classList.add('active-focus');
        }
        if (window.TVNavigation && typeof window.TVNavigation.markDirty === 'function') {
            window.TVNavigation.markDirty();
        }
        window.history.pushState(null, "", window.location.href);
        return true;
    }
    var comingSoon = document.getElementById("comingSoonOverlay");
    if (comingSoon && comingSoon.style.display === "flex") {
        comingSoon.style.display = "none";
        var items = document.querySelectorAll('.icon-item');
        if (items[3]) items[3].focus();
        window.history.pushState(null, "", window.location.href);
        return true;
    }
    var appsOverlay = document.getElementById("appsOverlay");
    if (appsOverlay && appsOverlay.classList.contains("show")) {
        closeAppsOverlay();
        window.history.pushState(null, "", window.location.href);
        return true;
    }
    var overlay = document.getElementById("subPageOverlay");
    if (overlay && overlay.style.display === "block") {
        closeSubPage();
        window.history.pushState(null, "", window.location.href);
        return true;
    }
    return false;
};

window.onTVNavigate = function (direction, active) {
    var isIndex = window.location.pathname.indexOf('index.html') !== -1 || window.location.pathname.split('/').pop() === '';
    var anyOverlayOpen = window.__appsOverlayOpen || window.__inputOverlayOpen || window.__castOverlayOpen || window.__citySelectorOpen;

    var subPage = document.getElementById('subPageOverlay');
    if (subPage && subPage.style.display === 'block') anyOverlayOpen = true;

    if (isIndex && !anyOverlayOpen) {
        if (direction === "left") {
            rotate("left");
            return true;
        }
        if (direction === "right") {
            rotate("right");
            return true;
        }
    }
    return false;
};
