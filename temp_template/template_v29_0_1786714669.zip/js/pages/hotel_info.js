let images = [];
let currentIndex = 0;
let autoTimer;

function waitForLoginData() {
    return new Promise(resolve => {
        if (window.tvLoginData) return resolve(window.tvLoginData);
        if (window.parent && window.parent.tvLoginData) return resolve(window.parent.tvLoginData);

        // Check local storage cache immediately
        const cached = localStorage.getItem('cachedHotelData');
        if (cached) {
            try { return resolve(JSON.parse(cached)); } catch (e) { }
        }

        const check = setInterval(() => {
            const data = window.tvLoginData || (window.parent && window.parent.tvLoginData);
            if (data) {
                clearInterval(check);
                resolve(data);
            }
        }, 100);

        // Increase timeout from 3000ms to 8000ms for slow TV hardware
        setTimeout(() => { clearInterval(check); resolve(null); }, 8000);
    });
}

async function fetchHotelConfig() {
    // 1. Try window variable injected by Flutter
    const injected = await waitForLoginData();
    if (injected) {
        var normalized = injected.data || injected;
        localStorage.setItem('cachedHotelData', JSON.stringify(normalized));
        return normalized;
    }

    // 2. Fallback to local files
    const filename = window.parent.HOTEL_DATA_FILE || window.HOTEL_DATA_FILE || 'data.json';
    const paths = [`../${filename}`, filename, '../data.json', 'data.json'];
    let config = null;

    for (let path of paths) {
        try {
            const res = await fetch(`${path}?t=${Date.now()}`);
            if (res.ok) {
                config = await res.json();
                config = config.data || config;
                localStorage.setItem('cachedHotelData', JSON.stringify(config));
                break;
            }
        } catch (e) {
            console.warn(`Failed to fetch config from ${path}:`, e);
        }
    }

    // 3. Fallback to local storage cache
    if (!config) {
        const cached = localStorage.getItem('cachedHotelData');
        if (cached) {
            try {
                config = JSON.parse(cached);
            } catch (e) {
                console.error("Failed parsing cached config:", e);
            }
        }
    }
    return config;
}

function updateHotelDetails(config) {
    if (config && config.hotel) {
        var h = config.hotel;
        var nameEl = document.getElementById('hotelName');
        if (nameEl) nameEl.textContent = h.hotel_name || 'Hotel Name';

        var locEl = document.getElementById('hotelLocation');
        if (locEl) locEl.textContent = h.hotel_location || h.address || ' Location';

        var descEl = document.getElementById('hotelDescription');
        if (descEl) descEl.textContent = h.description || 'Welcome to our hotel. We are committed to providing you with premium hospitality, luxury accommodations, and world-class amenities during your stay.';

        var contacts = h.emergency_contacts || {};

        var phoneEl = document.getElementById('hotelPhone');
        if (phoneEl) phoneEl.textContent = contacts.reception || h.phone || 'Ext. 0 / +91 98765 43210';

        var emailEl = document.getElementById('hotelEmail');
        if (emailEl) emailEl.textContent = contacts.email || h.email || 'support@hotel.com';

        var diningEl = document.getElementById('diningContact');
        if (diningEl) diningEl.textContent = contacts.dining || h.dining_contact || 'Ext. 102 (24x7 Available)';

        var emergencyEl = document.getElementById('emergencyContact');
        if (emergencyEl) emergencyEl.textContent = contacts.medical_sos || h.emergency_contact || 'Ext. 999 (Emergency Desk)';

        // Render dynamic amenities pills
        if (h.hotel_amenities && Array.isArray(h.hotel_amenities) && h.hotel_amenities.length > 0) {
            var container = document.querySelector('.amenities-pills');
            if (container) {
                container.innerHTML = '';
                h.hotel_amenities.forEach(function (item) {
                    var pill = document.createElement('span');
                    pill.className = 'pill';
                    pill.textContent = item;
                    container.appendChild(pill);
                });
            }
        }
    }
}

let bgSlideImages = [];
let bgCurrentImageIndex = 0;
let bgActiveSlideIndex = 0;
let bgSliderIntervalId = null;

function initBackgroundSlider(config) {
    if (bgSliderIntervalId) clearInterval(bgSliderIntervalId);
    bgSlideImages = [];

    const isInSubfolder = window.location.pathname.indexOf('/') !== window.location.pathname.lastIndexOf('/');
    const basePath = isInSubfolder ? '../' : '';

    if (config && config.hotel && config.hotel.media) {
        if (config.hotel.media.slider_images && config.hotel.media.slider_images.length > 0) {
            bgSlideImages = config.hotel.media.slider_images.map(img => {
                return (img.startsWith('http') || img.startsWith('/')) ? img : basePath + img;
            });
        } else if (config.hotel.media.cover_image) {
            let cover = config.hotel.media.cover_image;
            if (!cover.startsWith('http') && !cover.startsWith('/')) {
                cover = basePath + cover;
            }
            bgSlideImages = [cover];
        }
    }

    if (bgSlideImages.length === 0) {
        bgSlideImages = ['../images/main.jpg'];
    }

    const slides = document.querySelectorAll('#bg-slider .slide');
    if (slides.length < 2) return;

    // Load initial background image
    const tempImg1 = new Image();
    tempImg1.onload = () => {
        slides[0].style.backgroundImage = `url('${bgSlideImages[0]}')`;
        slides[0].classList.add('active');
        slides[1].classList.remove('active');
    };
    tempImg1.onerror = () => {
        slides[0].style.backgroundImage = "url('../images/main.jpg')";
        slides[0].classList.add('active');
        slides[1].classList.remove('active');
    };
    tempImg1.src = bgSlideImages[0];

    bgCurrentImageIndex = 0;
    bgActiveSlideIndex = 0;

    if (bgSlideImages.length > 1) {
        bgSliderIntervalId = setInterval(() => {
            bgCurrentImageIndex = (bgCurrentImageIndex + 1) % bgSlideImages.length;
            const nextSlideIndex = bgActiveSlideIndex === 0 ? 1 : 0;
            const targetUrl = bgSlideImages[bgCurrentImageIndex];

            const tempImgNext = new Image();
            tempImgNext.onload = () => {
                slides[nextSlideIndex].style.backgroundImage = `url('${targetUrl}')`;
                slides[nextSlideIndex].classList.add('active');
                slides[bgActiveSlideIndex].classList.remove('active');
                bgActiveSlideIndex = nextSlideIndex;
            };
            tempImgNext.onerror = () => {
                slides[nextSlideIndex].style.backgroundImage = "url('../images/main.jpg')";
                slides[nextSlideIndex].classList.add('active');
                slides[bgActiveSlideIndex].classList.remove('active');
                bgActiveSlideIndex = nextSlideIndex;
            };
            tempImgNext.src = targetUrl;
        }, 5000);
    }
}

async function initGallery() {
    // Load dynamic configuration instantly from parent cache if available
    const cachedConfig = (window.parent && window.parent.getFastConfig) ? window.parent.getFastConfig() : null;
    images = [];

    const isInSubfolder = window.location.pathname.indexOf('/') !== window.location.pathname.lastIndexOf('/');
    const basePath = isInSubfolder ? '../' : '';

    if (cachedConfig) {
        initBackgroundSlider(cachedConfig);
        updateHotelDetails(cachedConfig);
        if (cachedConfig.hotel && cachedConfig.hotel.media) {
            const m = cachedConfig.hotel.media;
            const galleryList = m.hotel_images || m.slider_images;
            if (galleryList && galleryList.length > 0) {
                images = galleryList.map(img => {
                    return (img.startsWith('http') || img.startsWith('/')) ? img : basePath + img;
                });
            } else if (m.cover_image) {
                let cover = m.cover_image;
                if (!cover.startsWith('http') && !cover.startsWith('/')) {
                    cover = basePath + cover;
                }
                images = [cover];
            }
        }
    } else {
        initBackgroundSlider(null);
    }

    // Run updated fetch in the background to avoid blocking initial render
    fetchHotelConfig().then(config => {
        if (config) {
            if (typeof window.checkPlanExpiredRedirect === 'function') window.checkPlanExpiredRedirect(config, '../index.html');
            initBackgroundSlider(config);
            updateHotelDetails(config);

            let newImages = [];
            if (config.hotel && config.hotel.media) {
                const m = config.hotel.media;
                const galleryList = m.hotel_images || m.slider_images;
                if (galleryList && galleryList.length > 0) {
                    newImages = galleryList.map(img => {
                        return (img.startsWith('http') || img.startsWith('/')) ? img : basePath + img;
                    });
                } else if (m.cover_image) {
                    let cover = m.cover_image;
                    if (!cover.startsWith('http') && !cover.startsWith('/')) {
                        cover = basePath + cover;
                    }
                    newImages = [cover];
                }
            }
            if (newImages.length > 0 && JSON.stringify(newImages) !== JSON.stringify(images)) {
                images = newImages;
                currentIndex = 0;
                updateDisplay();
                startAutoSlide();
            }
        }
    }).catch(err => console.warn("Background fetch failed:", err));

    // Standard local offline default fallback
    if (images.length === 0) {
        if (window.AndroidBridge && window.AndroidBridge.getPictureList) {
            try {
                const listString = window.AndroidBridge.getPictureList();
                images = JSON.parse(listString);
            } catch (e) { }
        }
    }

    if (images.length === 0) {
        images = ["../images/main.jpg"];
    }

    updateDisplay();
    startAutoSlide();

    let langFile = localStorage.getItem('selectedLangFile') || 'english.json';

    if (window.AndroidBridge && window.AndroidBridge.getSelectedLanguageFile) {
        langFile = window.AndroidBridge.getSelectedLanguageFile();
    }

    fetch(`../languages/${langFile}?t=${Date.now()}`)
        .then(res => res.json())
        .then(data => {
            const titleEl = document.getElementById('headerTitle');
            if (titleEl) {
                if (data.icons && data.icons.hotel_information) {
                    titleEl.innerText = data.icons.hotel_information;
                } else if (data.icons && data.icons.hotel_info) {
                    titleEl.innerText = (data.icons.hotel_info.toLowerCase() === 'hotel info') ? 'Hotel Information' : data.icons.hotel_info;
                } else {
                    titleEl.innerText = 'Hotel Information';
                }
            }
        })
        .catch(err => console.error("Language load error:", err));
}
let isTransitioning = false;

function updateDisplay(dir = 1) {
    if (!images || images.length === 0) {
        images = ["../images/main.jpg"];
    }
    const currentEl = document.getElementById('slideCurrent');
    const nextEl = document.getElementById('slideNext');

    if (!currentEl || !nextEl) return;

    const targetItem = images[currentIndex] || "../images/main.jpg";
    const targetSrc = (typeof targetItem === 'object' && targetItem.image_url) ? targetItem.image_url : targetItem;

    // Render dots and badges
    const badgeEl = document.getElementById('amenityBadge');
    if (badgeEl) {
        const num = currentIndex + 1;
        badgeEl.innerText = num < 10 ? `0${num}` : `${num}`;
    }

    const dotsContainer = document.getElementById('slideDots');
    if (dotsContainer) {
        dotsContainer.innerHTML = '';
        images.forEach((_, idx) => {
            const dot = document.createElement('div');
            dot.className = `slide-dot ${idx === currentIndex ? 'active' : ''}`;
            dotsContainer.appendChild(dot);
        });
    }

    // Initial render if currentSrc is empty or uninitialized
    if (!currentEl.getAttribute('src')) {
        currentEl.src = targetSrc;
        currentEl.className = 'slide-img active';
        return;
    }

    if (isTransitioning) return;
    isTransitioning = true;

    const inClass = dir >= 0 ? 'slide-in-right' : 'slide-in-left';
    const outClass = dir >= 0 ? 'slide-out-left' : 'slide-out-right';

    nextEl.src = targetSrc;
    nextEl.className = 'slide-img ' + inClass + ' active';
    currentEl.className = 'slide-img ' + outClass;

    setTimeout(() => {
        currentEl.src = targetSrc;
        currentEl.className = 'slide-img active';
        nextEl.className = 'slide-img';
        nextEl.src = '';
        isTransitioning = false;
    }, 600);
}

function changeSlide(dir) {
    if (images.length <= 1 || isTransitioning) return;
    currentIndex = (currentIndex + dir + images.length) % images.length;
    updateDisplay(dir);
    startAutoSlide();
}

function startAutoSlide() {
    clearInterval(autoTimer);
    if (images.length > 1) {
        autoTimer = setInterval(() => {
            currentIndex = (currentIndex + 1) % images.length;
            updateDisplay(1);
        }, 6000);
    }
}

function trigger(id) {
    const el = document.getElementById(id);
    if (el) {
        el.classList.add('vibrate');
        setTimeout(() => el.classList.remove('vibrate'), 400);
    }
}

function goBack() {
    sessionStorage.setItem('hotelMenuLastIndex', '0');
    window.location.href = "hotel_info_menu.html";
}

window.onTVNavigate = function (direction) {
    if (direction === 'left') {
        changeSlide(-1);
        return true;
    }
    if (direction === 'right') {
        changeSlide(1);
        return true;
    }
    return false;
};

window.onTVBack = function () {
    goBack();
    return true;
};

window.onload = () => {
    initGallery();
    setTimeout(() => {
        const slider = document.getElementById('amenitiesSlider');
        if (slider) slider.focus();
    }, 200);
};